(function( $ ) {
	'use strict';

	setTimeout(console.log.bind(console, '%cEVENTS CALENDAR - WP MONTHLY EVENTS', 'color: #B721FF;font-weight:bold;font-size:20px'), 0);

})( jQuery );
